import { randomUUID } from 'node:crypto';
const COLORS=['R','G','B','Y'];
const NUMS=['0','1','2','3','4','5','6','7','8','9'];
const SPECIAL=['S','R','D2'];
const WILDS=['W','W4','W6','W10'];
function makeDeck(){
  const deck=[];
  for(const c of COLORS){
    for(const n of NUMS) deck.push(c+n);
    for(const s of SPECIAL){ deck.push(c+s); deck.push(c+s); }
  }
  WILDS.forEach(w=>{ for(let i=0;i<4;i++) deck.push(w); });
  return shuffle(deck);
}
function shuffle(arr){
  const a=[...arr];
  for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; }
  return a;
}
export function createRoom(hostName){
  return {
    id: randomUUID().slice(0,8),
    status:'lobby',
    createdAt: Date.now(),
    players: [{id:randomUUID(),name:hostName,wins:0,connected:true}],
    settings: { minPlayers:2, maxPlayers:8, unoMode:'manual', stacking:'higher', mercy:true, drawRule:'untilPlayable', seven:true, zero:true, timerSec:30 },
    game:null,
    history:[]
  };
}
export function joinRoom(room, name){
  if(room.status!=='lobby') throw new Error('Game already started');
  if(room.players.length>=room.settings.maxPlayers) throw new Error('Room full');
  const p={id:randomUUID(),name, wins:0, connected:true}; room.players.push(p); return p;
}
export function startGame(room){
  if(room.players.length<room.settings.minPlayers) throw new Error('Not enough players');
  const deck=makeDeck();
  const hands={};
  for(const p of room.players) hands[p.id]=deck.splice(0,7);
  let top=deck.shift();
  while(/[A-Z]/.test(top.slice(1)) || top.startsWith('W')) top=deck.shift();
  room.status='playing';
  room.game={ deck, discard:[top], hands, dealerIndex:Math.floor(Math.random()*room.players.length), currentIndex:0, direction:1, stackTotal:0, winnerId:null, turnStartedAt:Date.now(), actionLog:[`Game started. ${top} opened.`] };
  room.game.currentIndex=(room.game.dealerIndex+1)%room.players.length;
  return room.game;
}
export function getCurrentPlayer(room){ return room.players[room.game.currentIndex]; }
export function playCard(room, playerId, card){
  const g=room.game; const player=getCurrentPlayer(room);
  if(!g || room.status!=='playing') throw new Error('No active game');
  if(player.id!==playerId) throw new Error('Not your turn');
  const hand=g.hands[playerId];
  const idx=hand.indexOf(card); if(idx<0) throw new Error('Card not in hand');
  hand.splice(idx,1); g.discard.push(card); g.actionLog.unshift(`${player.name} played ${card}`); g.actionLog=g.actionLog.slice(0,8);
  if(hand.length===0){ room.status='finished'; g.winnerId=playerId; return { winnerId:playerId }; }
  g.currentIndex=nextIndex(room, g.currentIndex, 1);
  g.turnStartedAt=Date.now();
  return { ok:true };
}
export function drawCard(room, playerId){
  const g=room.game; const player=getCurrentPlayer(room);
  if(player.id!==playerId) throw new Error('Not your turn');
  if(!g.deck.length) reshuffle(room);
  g.hands[playerId].push(g.deck.shift());
  g.actionLog.unshift(`${player.name} drew a card`); g.actionLog=g.actionLog.slice(0,8);
  g.currentIndex=nextIndex(room,g.currentIndex,1); g.turnStartedAt=Date.now();
  return { ok:true };
}
function reshuffle(room){
  const g=room.game; const top=g.discard.pop(); g.deck=shuffle(g.discard); g.discard=[top]; g.actionLog.unshift('Deck reshuffled');
}
function nextIndex(room, from, step){ return (from + step + room.players.length) % room.players.length; }
