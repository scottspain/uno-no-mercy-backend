import express from 'express';
import cors from 'cors';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import { createRoom, joinRoom, startGame, playCard, drawCard } from './gameEngine.js';

const app = express();
app.use(cors());
app.use(express.json());
const server = createServer(app);
const wss = new WebSocketServer({ server });
const rooms = new Map();

function snapshot(room){
  return {
    id: room.id,
    status: room.status,
    players: room.players.map(p=>({id:p.id,name:p.name,connected:p.connected})),
    settings: room.settings,
    game: room.game ? {
      currentPlayerId: room.players[room.game.currentIndex]?.id,
      topDiscard: room.game.discard.at(-1),
      stackTotal: room.game.stackTotal,
      direction: room.game.direction,
      winnerId: room.game.winnerId,
      actionLog: room.game.actionLog,
      handCounts: Object.fromEntries(Object.entries(room.game.hands).map(([id,h])=>[id,h.length]))
    } : null
  };
}
function broadcast(room){
  const message = JSON.stringify({ type:'room:update', room: snapshot(room) });
  wss.clients.forEach(client=>{ if(client.readyState===1 && client.roomId===room.id) client.send(message); });
}
app.get('/health', (_,res)=>res.json({ok:true}));
app.post('/rooms', (req,res)=>{ const room=createRoom(req.body.hostName||'Host'); rooms.set(room.id, room); res.json({room: snapshot(room), playerId: room.players[0].id}); });
app.post('/rooms/:id/join', (req,res)=>{ try{ const room=rooms.get(req.params.id); if(!room) return res.status(404).json({error:'Room not found'}); const p=joinRoom(room, req.body.name||'Player'); broadcast(room); res.json({room:snapshot(room), playerId:p.id}); }catch(e){ res.status(400).json({error:e.message}); } });
app.post('/rooms/:id/start', (req,res)=>{ try{ const room=rooms.get(req.params.id); if(!room) return res.status(404).json({error:'Room not found'}); startGame(room); broadcast(room); res.json({room:snapshot(room)}); }catch(e){ res.status(400).json({error:e.message}); } });
app.post('/rooms/:id/play', (req,res)=>{ try{ const room=rooms.get(req.params.id); const result=playCard(room, req.body.playerId, req.body.card); broadcast(room); res.json({result, room:snapshot(room)}); }catch(e){ res.status(400).json({error:e.message}); } });
app.post('/rooms/:id/draw', (req,res)=>{ try{ const room=rooms.get(req.params.id); const result=drawCard(room, req.body.playerId); broadcast(room); res.json({result, room:snapshot(room)}); }catch(e){ res.status(400).json({error:e.message}); } });

wss.on('connection', (ws, req)=>{
  const params = new URL(req.url, 'http://localhost').searchParams;
  ws.roomId = params.get('roomId');
  ws.send(JSON.stringify({ type:'connected', roomId: ws.roomId }));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=>console.log(`No Mercy backend on ${PORT}`));
